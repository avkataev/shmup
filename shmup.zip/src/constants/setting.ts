export const setting = {
    width: 480,
    height: 320,
}

export const colors = {
    field: '#eee',
    player: '#0095DD',
    bricks: '#0095DD',
    bullets: '#dd0000',
}
